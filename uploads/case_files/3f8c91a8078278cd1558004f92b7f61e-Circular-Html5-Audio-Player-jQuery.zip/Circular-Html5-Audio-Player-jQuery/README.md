# multiple-circular-player
 Concept for a multiple circular html5 audio player, using svg 
 HTML5 audio player with a circular SVG progress bar and complete fallback

inspired by https://github.com/frumbert/circular-player


Demo Page : https://kuantal.github.io/Multiple-circular-player/

* For custom size change "data-size='250'" tag 

Screenshot:

![alt text](screenshot.png)


## Licence
MIT.
